This is a simple example of how to use the input system in EditorWindow code.

For more details see the [documentation](https://docs.unity3d.com/Packages/com.unity.inputsystem@latest/index.html?subfolder=/manual/UseInEditor.html).
